package com.example.demo.model;

import java.util.List;

public class OcrResponse {
    private boolean success;
    private List<String> lines;
    private String errorMessage;

    public static OcrResponse success(List<String> lines) {
        OcrResponse response = new OcrResponse();
        response.success = true;
        response.lines = lines;
        return response;
    }

    public static OcrResponse error(String errorMessage) {
        OcrResponse response = new OcrResponse();
        response.success = false;
        response.errorMessage = errorMessage;
        return response;
    }

    // Getters and setters
}