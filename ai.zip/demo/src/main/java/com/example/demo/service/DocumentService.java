package com.example.demo.service;


import com.azure.ai.formrecognizer.documentanalysis.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.documentanalysis.DocumentAnalysisClientBuilder;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.ai.formrecognizer.documentanalysis.models.AnalyzeResult;
import com.azure.ai.formrecognizer.documentanalysis.models.DocumentParagraph;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.BinaryData;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.stream.Collectors;
import com.azure.core.credential.AzureKeyCredential;
import com.example.demo.exception.OcrProcessingException;
import com.example.demo.model.OcrResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentService.class);
    private static final long MAX_FILE_SIZE = 4 * 1024 * 1024; // 4MB

    @Value("${azure.document.key}")
    private String apiKey;

    @Value("${azure.document.endpoint}")
    private String endpoint;

    public OcrResponse analyzeDocument(MultipartFile file) {
        validateImage(file);

        try {
            DocumentAnalysisClient client = new DocumentAnalysisClientBuilder()
                    .credential(new AzureKeyCredential(apiKey))
                    .endpoint(endpoint)
                    .buildClient();

            byte[] fileBytes = file.getBytes();
            AnalyzeResult analyzeResult = client.beginAnalyzeDocument("prebuilt-read", BinaryData.fromBytes(fileBytes))
                    .getFinalResult();

            List<String> lines = analyzeResult.getPages().stream()
                    .flatMap(page -> page.getLines().stream())
                    .map(line -> line.getContent())
                    .collect(Collectors.toList());
            if (!lines.isEmpty()) {
                logger.info("Successfully processed document, found {} lines of text", lines.size());
                return OcrResponse.success(lines);
            } else {
                logger.warn("No text detected in the document");
                return OcrResponse.error("No text detected in the document");
            }
        } catch (Exception e) {
            logger.error("Failed to process document", e);
            throw new OcrProcessingException("Failed to process document: " + e.getMessage(), e);
        }
    }

    private void validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new OcrProcessingException("Document file is required");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new OcrProcessingException("File size exceeds maximum limit of 4MB");
        }
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            throw new OcrProcessingException("Invalid file type. Only image files are allowed");
        }
    }
}